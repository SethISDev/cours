git check-ignore **/*
